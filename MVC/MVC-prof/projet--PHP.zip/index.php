<?php
/** FICHIER D'ENTREE DU PROJET **/

// Chargement des controleurs
require 'routes/routes.php';

routes();