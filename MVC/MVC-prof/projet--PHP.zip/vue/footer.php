<footer class="container-fluid">
    <div class="row">
        <h1 class="col-12 col-lg-4">Projet PHP</h1>
        <nav class="col-12 col-lg-4">
            <h2>Liens utiles</h2>
            <ul>
                <li>Nous contacter</li>
            </ul>
        </nav>
        <nav class="col-12 col-lg-4">
            <h2>Réseaux sociaux</h2>

            <ul>
                <li>Facebook</li>
                <li>Instagram</li>
            </ul>
        </nav>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>