<!DOCTYPE html>
<html>
    <head>
        <?php
        include_once('head.php');
        ?>
    </head>
    <body>
        <?php
        include_once('header.php');
        ?>

        <div class="container">
            <main>
                Bienvenue sur la page d'inscription
            </main>
        </div>
        <?php
        include_once('footer.php');
        ?>
    </body>
</html>